function Spinner(){
    return (
        <div class="spinner"></div>
    );
}

export default Spinner;