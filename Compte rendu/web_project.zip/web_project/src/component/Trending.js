import React from "react";

function Trending() {
    return(
        <div id="trending">
            <div id="trendingtitle">Trending in the World</div>
            <div class="trendingtag">Placeholder tag <div class="trendingnumber">0000 Posts</div></div>
            <div class="trendingtag">Placeholder tag <div class="trendingnumber">0000 Posts</div></div>
            <div class="trendingtag">Placeholder tag <div class="trendingnumber">0000 Posts</div></div>
            <div class="trendingtag">Placeholder tag <div class="trendingnumber">0000 Posts</div></div>
        </div>
    );
}


export default Trending